package goibibo_test;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import goibibo_source.GBB_Registration;
@Listeners(utility.GB_Listeners.class)
public class TC_2_Login_With_Valid_Credential extends LaunchQuit{

	@Test(groups= {"smoke"})
	public void login_with_invalid() throws InterruptedException
	{
		
		GBB_Registration gr1 = new GBB_Registration(driver);
		gr1.mob_num();
		Thread.sleep(18000);
		Assert.assertEquals(gr1.error_message.isDisplayed(), true);
		Reporter.log("Tested login with invalid credentials and proper error messages are displayed");
	}
	
}
