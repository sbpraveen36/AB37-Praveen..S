package goibibo_test;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import goibibo_source.GBB_Registration;
import utility.Data_Fetching;

@Listeners(utility.GB_Listeners.class)
public class TC_1_Registration extends LaunchQuit {
	
	//WebDriver driver;
	@Test(groups= {"smoke"})
	public void register() throws EncryptedDocumentException, IOException, InterruptedException
	{
		
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		Thread.sleep(2000);
		GBB_Registration r1 = new GBB_Registration(driver);
		r1.mob_num();
		r1.continue_btn();
		Thread.sleep(18000);
		r1.name();
		r1.mail_address();
		r1.go_btn();
		Thread.sleep(3000);
		Assert.assertEquals(r1.traveller.getText(), "HeyPraveen");
		Reporter.log("Login successful");
		
	}

}
