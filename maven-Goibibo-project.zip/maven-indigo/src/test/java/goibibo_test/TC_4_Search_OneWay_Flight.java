package goibibo_test;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import goibibo_source.GBB_MainPage;
import goibibo_source.GBB_Registration;
import utility.Data_Fetching;

@Listeners(utility.GB_Listeners.class)

public class TC_4_Search_OneWay_Flight extends LaunchQuit {

	@Test(groups= {"Integration"})
	public void oneway_flight_search() throws EncryptedDocumentException, IOException, InterruptedException
	{
		
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		Thread.sleep(2000);	
		GBB_MainPage gm1 = new GBB_MainPage(driver);
		gm1.close_login_window();
		gm1.from_source();
		Thread.sleep(2000);
		gm1.enter_source();
		gm1.select_source();
		Thread.sleep(2000);
		gm1.to_dest();
		Thread.sleep(2000);
		gm1.select_dest();
		gm1.date();
		Thread.sleep(2000);
		gm1.flight_search(driver);
		System.out.println(driver.getTitle());
		Assert.assertEquals(driver.getTitle(), "Book Cheap Flights, Air Tickets, Hotels, Bus & Holiday Package at Goibibo");
		Reporter.log("Flight search successfull");	
	}
	
	
}
