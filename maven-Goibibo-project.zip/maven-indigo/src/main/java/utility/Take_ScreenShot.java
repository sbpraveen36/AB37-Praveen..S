package utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


public class Take_ScreenShot 
{
	public static void Test_Pass(WebDriver driver) throws IOException {
		TakesScreenshot TS= (TakesScreenshot) driver;
		File source=TS.getScreenshotAs(OutputType.FILE);
		File destini=new File("E:\\Screnshot\\Pass"+Math.random()+".png");
		FileUtils.copyFile(source, destini);
	}
	
	public static void Test_Fail(WebDriver driver) throws IOException {
		TakesScreenshot Tb= (TakesScreenshot) driver;
		File src=Tb.getScreenshotAs(OutputType.FILE);
		File destini=new File("E:\\Screnshot\\Fail"+Math.random()+".png");
		FileUtils.copyFile(src, destini);
	}
	
	
	
	
}
