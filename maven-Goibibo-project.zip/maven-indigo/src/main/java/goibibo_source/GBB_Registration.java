package goibibo_source;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.Data_Fetching;

public class GBB_Registration extends Data_Fetching{

	//Step1:
	@FindBy(xpath="//input[@name=\"phone\"]")
	WebElement mobile_num;
	
	@FindBy(xpath="//button[@class=\"sc-dhKdcB cYwnDu  \"]")
	WebElement continue_button;
	
	@FindBy(xpath="(//input[@name=\"text\"])[1]")
	WebElement enter_name;
	
	@FindBy(xpath="(//input[@name=\"text\"])[2]")
	WebElement enter_mail_address;
	
	@FindBy(xpath="//button[@class=\"sc-feUZmu bHpjfF\"]")
	WebElement go_button;
	
	@FindBy(xpath="//*[@class=\"sc-1f95z5i-49 cLoXtX\"]")
	public WebElement traveller;
	
	@FindBy(xpath="//p[@class=\"errorMessage\"]")
	public WebElement error_message;
	
	
	
	//Step2:
	public void mob_num()
	{
		mobile_num.sendKeys("8095443566");		
	}
	public void continue_btn()
	{
		continue_button.click();
	}
	public void name()
	{
		enter_name.sendKeys("Praveen");
	}
	public void mail_address()
	{
		enter_mail_address.sendKeys("madhumati2103@gmail.com");
	}
	public void go_btn()
	{
		go_button.click();
	}
	public void tvlr()
	{
		traveller.getText();
	}
	
	
	//Step3:
	public GBB_Registration(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
}
