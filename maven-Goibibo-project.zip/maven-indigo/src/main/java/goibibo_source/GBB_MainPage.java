package goibibo_source;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GBB_MainPage {

	//Step1:
	@FindBy(xpath="(//ul[@class=\"sc-12foipm-68 iMiogo\"]/li)[2]")
	WebElement round_trip;
	
	@FindBy(xpath="//span[@class=\"sc-gsFSXq bGTcbn\"]/span")
	WebElement login_window;

	@FindBy(xpath="(//div[@class=\"sc-12foipm-2 eTBlJr fswFld \"])[1]")
	WebElement from_text;
	
	@FindBy(xpath="//div[@class=\"sc-12foipm-25 fbAAhv\"]/input")
	WebElement send_text;
	
	@FindBy(xpath="(//span[@class=\"autoCompleteTitle \"])[1]")
	WebElement select_from;
	
	@FindBy(xpath="//div[@class=\"sc-12foipm-25 fbAAhv\"]/input")
	WebElement to_text;
	
	@FindBy(xpath="(//ul[@id=\"autoSuggest-list\"]/li)[1]")
	WebElement select_to;
	
	@FindBy(xpath="(//div[@class=\"sc-12foipm-16 wRKJm fswFld \"])[5]")
	WebElement travellers_class;
	
	@FindBy(xpath="//*[@id=\"root\"]/div[4]/div/div/div[4]/span")
	WebElement search_flights;
	
	@FindBy(xpath="(//div[@class=\"sc-12foipm-2 eTBlJr fswFld \"])[3]")
	WebElement click_date;
	
	@FindBy(xpath="(//div[@class=\"DayPicker-NavBar\"]/span)[1]")
	WebElement back_button;
	
	@FindBy(xpath="(//div[@class=\"DayPicker-Day\"])[24]/p")
	WebElement select_date;
	
	@FindBy(xpath="(//div[@class=\"sc-12foipm-2 eTBlJr fswFld \"])[5]")
	WebElement flight_class;
	
	@FindBy(xpath="(//ul[@class=\"sc-12foipm-45 caZeZT\"]/li)[3]")
	WebElement business_class;
	
	@FindBy(xpath="(//ul[@class=\"sc-12foipm-45 caZeZT\"]/li)[1]")
	WebElement economy_class;
	
	@FindBy(xpath="(//ul[@class=\"sc-12foipm-45 caZeZT\"]/li)[4]")
	WebElement first_class;
	
	@FindBy(xpath="(//div[@class=\"sc-12foipm-62 cHjaTW\"]/a)[2]")
	WebElement done_button;
	
	@FindBy(xpath="(//ul[@class=\"sc-12foipm-68 iMiogo\"]/li)[3]")
	WebElement multi_city;
	
	@FindBy(xpath="(//div[@class=\"sc-12foipm-2 eTBlJr fswFld \"])[6]/p")
	WebElement to_city_2;
	
	@FindBy(xpath="//div[@class=\"sc-12foipm-25 fbAAhv\"]/input")
	WebElement to_city2_send_text;
	
	@FindBy(xpath="(//ul[@id=\"autoSuggest-list\"]/li)[1]")
	WebElement dest2_select;
	
	@FindBy(xpath="//div[@class=\"sc-12foipm-85 kSdJvm\"]/span")
	WebElement search;

	@FindBy(xpath="//div[@class=\"sc-12foipm-71 cJDpIZ\"]/span")
	WebElement multicity_search;
	
	@FindBy(xpath="//div[@class=\"sc-fifgRP iKzBkA\"]")
	WebElement profile;
	
	@FindBy(xpath="//a[@class=\"sc-krNlru iFbmbK\"]")
	WebElement view_profile;
	
	@FindBy(xpath="//button[@class=\"sc-11civud-0 fzjMGi\"]")
	WebElement logout_button;
	
	@FindBy(xpath="//button[@class=\"sc-sypgwv-6 kkbZLK\"]")
	WebElement logout_confirm_button;
	
	//Step2:
	public void logout_cnf_btn()
	{
		logout_confirm_button.click();
	}
	public void logout(WebDriver driver) throws InterruptedException
	{
		Point location = logout_button.getLocation();
		int x = location.getX();
		int y = location.getY();
		
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0, "+y+")");
		Thread.sleep(1000);
		logout_button.click();
	}
	public void profile_btn(WebDriver driver) throws InterruptedException
	{
		Actions action = new Actions(driver);
		//action.moveToElement(profile).build().perform();
	}
	public void view_profile_link(WebDriver driver)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\"sc-krNlru iFbmbK\"]")));

		view_profile.click();
	}
	public void dest2_city_select()
	{
		dest2_select.click();
	}
	public void dest_city2()
	{
		to_city_2.click();
	}
	public void dest_city2_txt()
	{
		to_city2_send_text.click();
		to_city2_send_text.sendKeys("Hubli");
	}
	public void multi_city_btn()
	{
		multi_city.click();
	}
	public void flight_class_select()
	{
		flight_class.click();
	}
	public void business_class_select()
	{
		business_class.click();
		done_button.click();
	}
	public void done_btn()
	{
		done_button.click();
	}
	public void economy_class_select()
	{
		economy_class.click();
		done_button.click();
	}
	public void first_class_select()
	{
		first_class.click();
		done_button.click();
	}
	public void date()
	{
		click_date.click();
		//back_button.click();
		select_date.click();
	}
	public void close_login_window()
	{
		login_window.click();
	}
	public void from_source()
	{
		from_text.click();
	}
	public void enter_source()
	{
		send_text.click();
		send_text.sendKeys("Bangalore");
	}
	public void select_source()
	{
		select_from.click();
	}
	public void to_dest()
	{
		to_text.sendKeys("delhi");
	}
	public void select_dest()
	{
		select_to.click();
	}
	public void flight_search(WebDriver driver) throws InterruptedException
	{
	
		int width = search_flights.getSize().getWidth();
		System.out.println("Width is -"+width);
		Actions act = new Actions(driver);
		act.moveToElement(search_flights).moveByOffset((width/2)-10, 0).click().perform();
		Thread.sleep(13000);
		
	}
	public void search_btn(WebDriver driver) throws InterruptedException
	{
		int width = search.getSize().getWidth();
		System.out.println("Width is -"+width);
		Actions act = new Actions(driver);
		act.moveToElement(search).moveByOffset((width/2)-10, 0).click().perform();
		Thread.sleep(10000);
	}
	public void multicity_search_btn(WebDriver driver) throws InterruptedException
	{
		int width = multicity_search.getSize().getWidth();
		System.out.println("Width is -"+width);
		Actions act = new Actions(driver);
		act.moveToElement(multicity_search).moveByOffset((width/2)-10, 0).click().perform();
		Thread.sleep(10000);
	}
	
	public void round_trip_btn()
	{
		round_trip.click();
	}
	
	//Step3:
	public GBB_MainPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
}
