package selenium_mavenproject.maven;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AMZ_B2C_MainPage_SearchPage {

	//Step1:
	 	@FindBy(id="twotabsearchtextbox")
	 	WebElement searchbox;
	 	
	 	@FindBy(xpath="//div[@id=\"departments\"]/div")
	 	WebElement product_category;
	 	
	 	@FindBy(xpath="(//div[@id=\"priceRefinements\"]/div)[1]")
	 	WebElement price_button;
	 	
	 	@FindBy(linkText="₹1,000 - ₹5,000")
	 	WebElement price_range;
	
	 	@FindBy(xpath="//div[@class=\\\"a-section a-spacing-small a-spacing-top-small\\\"]/span)[1]")
	 	WebElement filter_text;
	 	
	 	
	 	
	//Step2:
	 	public void search_box()
	 	{
	 		searchbox.sendKeys("headphones");
	 		searchbox.sendKeys(Keys.ENTER);
	 	}
	 	public void category()
	 	{
	 		product_category.click();
	 	}
	 	public void price_button()
	 	{
	 		price_button.click();
	 	}
	 	public void price()
	 	{
	 		price_range.click();
	 	}
	 	public void filter_txt()
	 	{
	 		filter_text.getText();
	 	}
	 	
	 	
	//Step3:
	 	public AMZ_B2C_MainPage_SearchPage(WebDriver driver)
		{
			PageFactory.initElements(driver, this);
		}	
	
}
