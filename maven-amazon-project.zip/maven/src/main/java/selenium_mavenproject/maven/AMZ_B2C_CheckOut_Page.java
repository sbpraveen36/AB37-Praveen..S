package selenium_mavenproject.maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AMZ_B2C_CheckOut_Page {

	//Step1:
	
	@FindBy(xpath="//a[@id=\"addressChangeLinkId\"]")
	WebElement address_change;
	
	@FindBy(xpath="(//input[@name=\"submissionURL\"])[2]")
	WebElement select_address;
	
	@FindBy(xpath="//span[@id=\"shipToThisAddressButton\"]")
	WebElement use_this_address_button;
	
	@FindBy(xpath="//a[@id=\"payChangeButtonId\"]")
	WebElement paychange;
	
	@FindBy(xpath="//input[@id=\"pp-4sClBJ-103\"]")
	WebElement netbanking_button;
	
	@FindBy(name="ppw-bankSelection_dropdown")
	WebElement netbanking_dd_option;
	
	@FindBy(xpath="(//input[@name=\"ppw-widgetEvent:SetPaymentPlanSelectContinueEvent\"])[1]")
	WebElement use_this_payment_method_button;
	
	@FindBy(xpath="//h3[@class=\"a-spacing-base a-spacing-top-micro\"]")
	WebElement review_delivery_message;
	
	@FindBy(xpath="(//*[@name=\"ppw-instrumentRowSelection\"])[1]")
	WebElement card_payment;
	
	@FindBy(linkText="Enter card details")
	WebElement enter_card_details_link;
	
	@FindBy(xpath="(//*[@name=\"ppw-instrumentRowSelection\"])[2]")
	WebElement netbanking_payment_option;
	
	@FindBy(xpath="(//*[@name=\"ppw-instrumentRowSelection\"])[3]")
	WebElement other_upi_app;
	
	@FindBy(xpath="(//*[@name=\"ppw-instrumentRowSelection\"])[4]")
	WebElement emi_payment;
	
	@FindBy(xpath="(//*[@name=\"ppw-instrumentRowSelection\"])[5]")
	WebElement cash_on_delivery;
	
	@FindBy(xpath="//*[@name=\"ppw-claimCode\"]")
	WebElement coupon_code;
	
	@FindBy(xpath="//*[@name=\"ppw-claimCodeApplyPressed\"]")
	WebElement coupon_code_apply;
	
	
	//Step2:
	public void card_details()
	{
		enter_card_details_link.click();
	}
	public void cc_dc_payment()
	{
		card_payment.click();
	}
	public void change_address()
	{
		address_change.click();
	}
	public void address_select()
	{
		select_address.click();
	}
	public void use_this_address_btn()
	{
		use_this_address_button.click();
	}
	public void pay_change()
	{
		paychange.click();
	}
	public void payment_method()
	{
		netbanking_button.click();
	}
	public void netbanking_bank_selection()
	{
		Select s1 = new Select(netbanking_dd_option);
		s1.selectByIndex(4);
	}
	public void payment_mtd_selection_btn()
	{
		use_this_payment_method_button.click();
	}
	public void net_banking_pay_opt()
	{
		netbanking_payment_option.click();
	}
	public void upi_apps()
	{
		other_upi_app.click();
	}
	public void emi()
	{
		emi_payment.click();
	}
	public void cash_pay()
	{
		cash_on_delivery.click();
	}
	public void coupon()
	{
		coupon_code.sendKeys("A5G63DHCKGJD784");
	}
	public void coupon_apply()
	{
		coupon_code_apply.click();
	}
	
	
	//Step3:
		public AMZ_B2C_CheckOut_Page(WebDriver driver)
		{
			PageFactory.initElements(driver, this);
		}
	
}
