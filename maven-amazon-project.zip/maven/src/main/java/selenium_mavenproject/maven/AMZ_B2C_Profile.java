package selenium_mavenproject.maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AMZ_B2C_Profile {

	//Step1:
	@FindBy(xpath="//span[@class=\"sc-ksBlkl sc-jRwbcX fedVjG fqsXfW\"]")
	WebElement manage_profile;
	
	@FindBy(xpath="//div[@class=\"sc-kgTSHT fKJwkr\"]/a")
	WebElement view_button;
	
	@FindBy(xpath="(//h3[@class=\"accordion-header\"])[2]/button/div")
	WebElement height_and_weight;
	
	@FindBy(xpath="(//button[@class=\"attribute-action\"])[3]")
	WebElement height_and_weight_edit;
	
	@FindBy(xpath="(//div[@class=\"number-input-option desktop\"])[1]/input")
	WebElement height;
	
	@FindBy(xpath="(//div[@class=\"number-input-option desktop\"])[2]/input")
	WebElement weight;
	
	@FindBy(xpath="//span[@class=\"a-button a-button-normal a-button-primary button\"]/span/input")
	WebElement ht_wt_save;
	
	@FindBy(xpath="(//h3[@class=\"accordion-header\"])[1]/button/div")
	WebElement department;
	
	@FindBy(xpath="//button[@class=\"attribute-action\"]")
	WebElement department_add;
	
	@FindBy(xpath="(//div[@class=\"options-list three-column-grid\"]/button)[2]")
	WebElement department_men;
	
	@FindBy(xpath="//div[@class=\"survey-footer\"]/div/span")
	WebElement department_save;
	
	//Step2:
	public void mng_profile()
	{
		manage_profile.click();
	}
	public void view_btn()
	{
		view_button.click();
	}
	public void dpt()
	{
		department.click();
	}
	public void dpt_add()
	{
		department_add.click();
	}
	public void dpt_men()
	{
		department_men.click();
	}
	public void dpt_save()
	{
		department_save.click();
	}
	public void ht_and_wt()
	{
		height_and_weight.click();
	}
	public void ht_wt_edit()
	{
		height_and_weight_edit.click();
	}
	public void add_height()
	{
		height.clear();
		height.sendKeys("170");
	}
	public void add_weight()
	{
		weight.clear();
		weight.sendKeys("68");
	}
	public void ht_wt_save_btn()
	{
		ht_wt_save.click();
	}
	
	//Step3:
	public AMZ_B2C_Profile(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}	

	
}
