package selenium_mavenproject.maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.Data_Fetching;
	
public class AMZ_B2C_Registration extends Data_Fetching {

	//Step1:
	@FindBy(xpath="(//div[@id='nav-tools']/a)[2]")
	WebElement hover_over;
	
	@FindBy(linkText="Start here.")
	WebElement start_here;
	
	@FindBy(id="ap_customer_name")
	WebElement your_name;
	
	@FindBy(id="ap_phone_number")
	WebElement mob_number;
	
	@FindBy(id="ap_password")
	WebElement pass_word;
	
	@FindBy(xpath="//span[@id=\"auth-continue\"]")
	WebElement verify_mob_number;
	
	
	
	
	
	//Step2:
	public void hover(WebDriver driver) {
	 Actions a1 = new Actions(driver);
	 a1.moveToElement(hover_over).perform();
		
	}
	
	public void reg_link()
	{
		start_here.click();
	}
	public void your_name()
	{
		your_name.sendKeys(yourname);
	}
	public void mob_num()
	{
		mob_number.sendKeys(username);
	}
	public void pwd()
	{
		pass_word.sendKeys(password);
	}
	public void verify_mob_num()
	{
		verify_mob_number.click();
	}
	
	
	
	//Step3:
	public AMZ_B2C_Registration(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
		
}
