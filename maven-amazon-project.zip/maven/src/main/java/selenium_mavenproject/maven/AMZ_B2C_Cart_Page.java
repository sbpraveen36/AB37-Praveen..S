package selenium_mavenproject.maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AMZ_B2C_Cart_Page {

	//Step1:
	@FindBy(linkText="Go to Cart")
	WebElement go_to_cart_button;
	
	@FindBy(xpath="//select[@name=\"quantity\"]")
	WebElement quantity_dropdown;
	
	@FindBy(xpath="(//div[@class='a-row sc-action-links']/span)[2]")
	WebElement delete_buton;
	
	@FindBy(xpath="//h1[@class=\"a-spacing-mini a-spacing-top-base\"]")
	WebElement cart_empty_message;
	
	@FindBy(xpath="//input[@id=\"buy-now-button\"]")
	WebElement buy_now_button;
	
	@FindBy(xpath="(//span[@id=\"attach-sidesheet-view-cart-button\"])[1]/span/input")
 	WebElement cart_button;
	
	//Step2:
	public void cart_btn()
	{
		cart_button.click();
	}
	public void go_cart()
	{
		go_to_cart_button.click();
	}
	public void select_qty()
	{
		Select s1 = new Select(quantity_dropdown);
		s1.selectByVisibleText("2");
	}
	public void delete_from_cart()
	{
		delete_buton.click();
	}
	public void proceed_buy()
	{
		buy_now_button.click();
	}
	
	//Step3:
	public AMZ_B2C_Cart_Page(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}

}
