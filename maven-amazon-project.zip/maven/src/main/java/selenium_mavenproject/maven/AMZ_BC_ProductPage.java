package selenium_mavenproject.maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AMZ_BC_ProductPage {
		
	
	//Step1:
	
	@FindBy(xpath="//div[@id=\"titleSection\"]")
	WebElement product_description;
	
	@FindBy(xpath="(//h2[@class=\"a-size-mini a-spacing-none a-color-base s-line-clamp-2\"])[1]/a/span")
	WebElement product_shoe;
	
	@FindBy(xpath="(//span[@class=\"a-price-whole\"])[1]")
	WebElement price1;
	
	@FindBy(xpath="(//span[@class=\"a-price-whole\"])[2]")
	WebElement price2;
	
	@FindBy(xpath="(//span[@id=\"acrPopover\"])[1]")
	WebElement user_rating1;
	
	@FindBy(xpath="(//span[@id=\"acrPopover\"])[2]")
	WebElement user_rating2;
	
	@FindBy(xpath="(//i[@class=\"a-icon a-icon-checkbox\"])[4]")
	WebElement sorting_brand;
	
	@FindBy(xpath="//div[@id=\"p_72-title\"]")
	WebElement rating_button;
	
	@FindBy(xpath="//i[@class=\"a-icon a-icon-star-medium a-star-medium-4\"]")
	WebElement sortrating;
	
	@FindBy(xpath="//li[@id=\"p_36/1318504031\"]")
	WebElement sortprice;
	
	@FindBy(id="add-to-cart-button")
	WebElement add_to_cart_button;
	
	@FindBy(linkText="Go to Cart")
 	WebElement gotocart_button;
	
	@FindBy(xpath="((//div[@class=\"a-section\"])[26]/span/a)[1]")
	WebElement expand;
	
	@FindBy(xpath="//div[@id=\"priceRefinements\"]")
	WebElement price_button;
	
	//Step2:
	public void price_btn()
	{
		price_button.click();
	}
	public void expand_btn()
	{
		expand.click();
	}
	public void pdt_shoe()
	{
		product_shoe.click();
	}
	public void pdt_description()
	{
		product_description.isDisplayed();
	}
	public void pdt_prce()
	{
		price1.isDisplayed();
		price2.isDisplayed();
	}
	public void user_rating()
	{
		user_rating1.isDisplayed();
		user_rating2.isDisplayed();
	}
	public void brand()
	{
		try {
		sorting_brand.click();
		}
		catch(Exception e)
		{
			expand.click();
			sorting_brand.click();
		}
	}
	public void rating_btn()
	{
		rating_button.click();
	}
	public void sort_rating()
	{
		sortrating.click();
	}
	public void sort_price()
	{
		sortprice.click();
	}
	public void add_to_cart()
	{
		add_to_cart_button.click();
	}
	public void cart()
	{
		gotocart_button.click();
	}
	
	
	//Step3:
	public AMZ_BC_ProductPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
}

