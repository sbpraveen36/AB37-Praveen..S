package selenium_mavenproject.maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.Data_Fetching;

public class AMZ_B2C_Login extends Data_Fetching {

	//Step1:
	@FindBy(xpath="(//div[@id='nav-tools']/a)[2]")
	WebElement hover_over;
	
	@FindBy(id="ap_email")
	WebElement email_tf;
	
	@FindBy(id="continue")
	WebElement continue_button;
	
	@FindBy(id="ap_password")
	WebElement password_tf;
	
	@FindBy(id="ap_password")
	WebElement password_tf1;
	
	@FindBy(xpath="//ul[@class=\"a-unordered-list a-nostyle a-vertical a-spacing-none\"]")
	WebElement alertmessage;
	
	@FindBy(id="signInSubmit")
	WebElement signin_button;

	//Step2:
	public void hover_over(WebDriver driver)
	{
	Actions a1 = new Actions(driver);
	a1.moveToElement(hover_over).perform();
	}
	public void signin()
	{
		hover_over.click();
	}
	public void un()
	{
		email_tf.sendKeys(username);
	}
	public void continue_btn()
	{
		continue_button.click();
	}
	public void pwd()
	{
		password_tf.sendKeys(password);
	}
	public void incorrect_pwd()
	{
		password_tf1.sendKeys(incorrectpassword);
	}
	public void alertmsg()
	{
		alertmessage.getText();
	}
	public void sign_btn()
	{
		signin_button.click();
	}
	
	//Step3:
	public AMZ_B2C_Login(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}	
}
