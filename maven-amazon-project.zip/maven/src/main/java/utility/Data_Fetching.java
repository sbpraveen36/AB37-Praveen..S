package utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.openqa.selenium.WebDriver;

public class Data_Fetching {

	public static String username;
	public static String password;
	public static String incorrectpassword;
	public static String yourname;
	public static String mobile_number;
	
	public void fetch() throws EncryptedDocumentException, IOException
	{
		FileInputStream f1 = new FileInputStream("C:\\Users\\praveen\\eclipse-workspace\\maven\\Excelfile\\aryan1.xlsx");
		Workbook wb = WorkbookFactory.create(f1);
		//username = wb.getSheet("login").getRow(0).getCell(0).getStringCellValue();
		username = NumberToTextConverter.toText(wb.getSheet("login").getRow(0).getCell(0).getNumericCellValue());
		password = wb.getSheet("login").getRow(1).getCell(0).getStringCellValue();
		incorrectpassword = wb.getSheet("login").getRow(2).getCell(0).getStringCellValue();
		yourname = wb.getSheet("login").getRow(3).getCell(0).getStringCellValue(); 
		//mobile_number=NumberToTextConverter(wb.getSheet("login").getRow(0).getCell(0).getNumericCellValue());

	}
 
 	

	public void window_switch(WebDriver driver)
	{
		Set <String> multiwindow = driver.getWindowHandles();
		Iterator <String> window_id = multiwindow.iterator();
		String penrent_window = window_id.next();
		String child_window = window_id.next();
		driver.switchTo().window(child_window);
	}
	 
}
