import org.testng.ITestListener;

public class Listeners_Class implements ITestListener
{

}
