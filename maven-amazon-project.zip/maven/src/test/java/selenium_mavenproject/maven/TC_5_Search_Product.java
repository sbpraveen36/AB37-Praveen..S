package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;

@Listeners(utility.Listener_Class.class)
public class TC_5_Search_Product extends LaunchQuit{

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void product_search() throws EncryptedDocumentException, IOException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Assert.assertEquals(driver.getTitle(), "Amazon.in : headphones");
		
		
		
	}
	
}
