package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;

@Listeners(utility.Listener_Class.class)
public class TC_9_Add_To_Cart extends LaunchQuit {
	
	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void add2cart() throws EncryptedDocumentException, IOException, InterruptedException
  {
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		Reporter.log("Login successful");
		Thread.sleep(2000);
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Thread.sleep(2000);
		Reporter.log("Product search ssuccessful");
		AMZ_BC_ProductPage p1 = new AMZ_BC_ProductPage(driver);
		p1.pdt_shoe();
		Thread.sleep(2000);
		d1.window_switch(driver);
		Reporter.log("Window switching ssuccessful");
		Thread.sleep(2000);
		p1.add_to_cart();
		Thread.sleep(2000);
		p1.cart();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getTitle(), "Amazon.in Shopping Cart");
		Reporter.log("Product added to cart page successfully");
		
	}
}
