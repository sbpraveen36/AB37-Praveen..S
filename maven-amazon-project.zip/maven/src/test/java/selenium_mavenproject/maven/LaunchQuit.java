package selenium_mavenproject.maven;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utility.Listener_Class;

public class LaunchQuit extends Listener_Class {

	//WebDriver driver;
	@BeforeMethod
	public void browser_launch()
	{
		driver = new EdgeDriver();
		driver.manage().window().maximize();	
		driver.get("https://amazon.in");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	}
	
	@AfterMethod
	public void beowser_quit()
	{
		System.out.println("Thanks test case execution is done");
		driver.quit();
	}
	
}
