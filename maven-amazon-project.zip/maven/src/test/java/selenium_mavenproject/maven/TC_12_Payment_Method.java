package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_12_Payment_Method extends LaunchQuit {

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void select_each_payment_method() throws EncryptedDocumentException, IOException, InterruptedException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver); //Login
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		Reporter.log("Login successfull");
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver); //Search product
		sp1.search_box();
		Reporter.log("Product search successfull");
		
		AMZ_BC_ProductPage p1 = new AMZ_BC_ProductPage(driver); //Clicking on 1st product
		p1.pdt_shoe();
		Reporter.log("Clicked in 1st product successfully");
		
		d1.window_switch(driver); //Window switching
		Reporter.log("Window switching successfull");
		
		AMZ_B2C_Cart_Page c1 = new AMZ_B2C_Cart_Page(driver); //Click on buy now
		c1.proceed_buy();
		
		Thread.sleep(10000);
		AMZ_B2C_CheckOut_Page co1 = new  AMZ_B2C_CheckOut_Page(driver);//Card payment selection
		co1.cc_dc_payment();
		Assert.assertEquals(co1.enter_card_details_link.getText(), "Enter card details");
		Reporter.log("Card payment selected successfully");
		
		Thread.sleep(2000);
		co1.net_banking_pay_opt();
		Assert.assertEquals(co1.netbanking_payment_option.isSelected(), true);
		Reporter.log("Net banking payment selected successfully");
		
		Thread.sleep(2000);
		co1.upi_apps();
		Assert.assertEquals(co1.other_upi_app.isSelected(), true);
		Reporter.log("UPI payment selected successfully");
		
		Thread.sleep(2000);
		co1.emi();
		Assert.assertEquals(co1.emi_payment.isSelected(), true);
		Reporter.log("EMI payment selected successfully");

		Thread.sleep(2000);
		co1.cash_pay();
		Assert.assertEquals(co1.cash_on_delivery.isSelected(), true);
		Reporter.log("Cash on delivery payment selected successfully");
					
	}
	
}
