package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_3_Login_With_Incorrect_Credentials extends LaunchQuit{

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void login_with_valid_credentials() throws InterruptedException, EncryptedDocumentException, IOException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.incorrect_pwd();
		l1.sign_btn();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getTitle(),"Amazon Sign In");
		
		
	}
	
	
}
