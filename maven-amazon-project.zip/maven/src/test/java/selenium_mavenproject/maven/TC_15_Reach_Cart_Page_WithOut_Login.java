package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_15_Reach_Cart_Page_WithOut_Login extends LaunchQuit {

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void reach_cart_page() throws EncryptedDocumentException, IOException, InterruptedException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Thread.sleep(2000);
		Reporter.log("Product search successful");
		AMZ_BC_ProductPage p1 = new AMZ_BC_ProductPage(driver);
		p1.pdt_shoe();
		Thread.sleep(2000);
		d1.window_switch(driver);
		Reporter.log("Window switching successful");
		Thread.sleep(2000);
		p1.add_to_cart();
		Reporter.log("Product added to cart successfully");
		Thread.sleep(2000);
		AMZ_BC_ProductPage pp1 = new AMZ_BC_ProductPage(driver);
		Thread.sleep(10000);
		pp1.cart();
		Reporter.log("Reached till cart page without login successfully");
		Assert.assertEquals(driver.getTitle(), "Amazon.in Shopping Cart");
		
	}
	
}
