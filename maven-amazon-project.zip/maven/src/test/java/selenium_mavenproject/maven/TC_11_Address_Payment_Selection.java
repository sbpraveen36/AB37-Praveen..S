package selenium_mavenproject.maven;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_11_Address_Payment_Selection extends LaunchQuit {

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void checkout_page() throws EncryptedDocumentException, IOException, InterruptedException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		Reporter.log("Login successful");
		Thread.sleep(2000);
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Thread.sleep(2000);
		Reporter.log("Product search successful");
		AMZ_BC_ProductPage p1 = new AMZ_BC_ProductPage(driver);
		p1.pdt_shoe();
		Thread.sleep(2000);
		d1.window_switch(driver);
		Reporter.log("Window switching successful");
		Thread.sleep(2000);
		AMZ_B2C_Cart_Page cp1 = new AMZ_B2C_Cart_Page(driver);
		cp1.proceed_buy();
		Thread.sleep(2000);
		AMZ_B2C_CheckOut_Page cp2 = new AMZ_B2C_CheckOut_Page(driver);
		cp2.change_address();
		cp2.address_select();
		cp2.use_this_address_btn();
		Thread.sleep(10000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(cp2.paychange));
		cp2.pay_change();
		//cp2.payment_method();
		Thread.sleep(5000);
		cp2.netbanking_bank_selection();
		cp2.payment_mtd_selection_btn();
		Assert.assertEquals(cp2.review_delivery_message.getText(), "Order Summary");
		Reporter.log("Order review, address and payment method selection done successfully");
		
	}
	
 }
