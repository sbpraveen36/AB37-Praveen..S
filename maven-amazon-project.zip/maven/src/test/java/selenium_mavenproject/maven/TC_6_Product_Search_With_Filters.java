package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;
import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_6_Product_Search_With_Filters extends LaunchQuit {

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void pdt_search_with_filters() throws InterruptedException, EncryptedDocumentException, IOException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		Reporter.log("Login successful");
		Thread.sleep(2000);
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Thread.sleep(2000);
		Reporter.log("Product seacrh ssuccessful");
		sp1.category();
		sp1.price_button();
		sp1.price();
		Reporter.log("Product seacrh with filter ssuccessful");
			
	}

}
