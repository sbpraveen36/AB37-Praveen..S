package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_13_Apply_Coupon_Code extends LaunchQuit {

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void apply_coupon_code() throws EncryptedDocumentException, IOException, InterruptedException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		Reporter.log("Sign in successful");
		
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Thread.sleep(2000);
		Reporter.log("Product search successful");
		
		AMZ_BC_ProductPage p1 = new AMZ_BC_ProductPage(driver);
		p1.pdt_shoe();
		Thread.sleep(2000);
		d1.window_switch(driver);
		Reporter.log("Window switching successful");
		
		AMZ_B2C_Cart_Page c1 = new AMZ_B2C_Cart_Page(driver); //Click on buy now
		c1.proceed_buy();
		
		Thread.sleep(2000);
		AMZ_B2C_CheckOut_Page co1 = new  AMZ_B2C_CheckOut_Page(driver);//Card payment selection
		co1.coupon();
		co1.coupon_apply();
		Reporter.log("Coupon code applied successfully");
		
	}
		
}
