package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;

@Listeners(utility.Listener_Class.class)
public class TC_4_Edit_Profile_Info extends LaunchQuit {
	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void login() throws InterruptedException, EncryptedDocumentException, IOException
	{
	
		AMZ_B2C_Login tc2 = new AMZ_B2C_Login(driver);
		tc2.signin();
		Thread.sleep(2000);
		tc2.un();
		tc2.continue_btn();
		tc2.pwd();
		tc2.sign_btn();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.hover_over(driver);
		AMZ_B2C_Profile p1 = new AMZ_B2C_Profile(driver);
		p1.mng_profile();
		p1.view_btn();
		Thread.sleep(5000);
		Assert.assertEquals(driver.getTitle(), "Profile Hub");
		Thread.sleep(2000);
		p1.dpt();
		p1.dpt_add();
		p1.dpt_men();
		p1.dpt_save();
		Thread.sleep(3000);
		p1.ht_and_wt();
		Thread.sleep(2000);
		p1.ht_wt_edit();
		p1.add_height();
		p1.add_weight();
		p1.ht_wt_save_btn();
		
		
	}
	
}
