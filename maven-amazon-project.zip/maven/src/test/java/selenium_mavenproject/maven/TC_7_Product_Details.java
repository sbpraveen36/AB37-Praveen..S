package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utility.Data_Fetching;
@Listeners(utility.Listener_Class.class)
public class TC_7_Product_Details extends LaunchQuit {
	
	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void product_details() throws EncryptedDocumentException, IOException, InterruptedException
	{	
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Login l1 = new AMZ_B2C_Login(driver);
		l1.signin();
		l1.un();
		l1.continue_btn();
		l1.pwd();
		l1.sign_btn();
		Reporter.log("Login successful");
		Thread.sleep(2000);
		AMZ_B2C_MainPage_SearchPage sp1 = new AMZ_B2C_MainPage_SearchPage(driver);
		sp1.search_box();
		Thread.sleep(2000);
		Reporter.log("Product search ssuccessful");
		AMZ_BC_ProductPage p1 = new AMZ_BC_ProductPage(driver);
		p1.pdt_shoe();
		Thread.sleep(2000);
		d1.window_switch(driver);
		Reporter.log("Window switching ssuccessful");
		p1.pdt_description();
		p1.pdt_prce();
		p1.user_rating();
		Reporter.log("Descrition, price and rating details displayed on product page");
		
	}
	
}
