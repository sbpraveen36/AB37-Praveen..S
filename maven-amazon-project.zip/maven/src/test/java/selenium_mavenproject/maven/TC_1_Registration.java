package selenium_mavenproject.maven;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import junit.framework.Assert;
import utility.Data_Fetching;

@Listeners(utility.Listener_Class.class)
public class TC_1_Registration extends LaunchQuit{

	@Test(retryAnalyzer=selenium_mavenproject.maven.Retry_Logic.class)
	public void TC_1_reg() throws EncryptedDocumentException, IOException
	{
		Data_Fetching d1 = new Data_Fetching();
		d1.fetch();
		AMZ_B2C_Registration r1 = new AMZ_B2C_Registration(driver);
		r1.reg_link();
		r1.your_name();
		r1.mob_num();
		r1.pwd();
		r1.verify_mob_num();
		Assert.assertEquals(driver.getTitle(), "Authentication required");
		
	}
	
}
