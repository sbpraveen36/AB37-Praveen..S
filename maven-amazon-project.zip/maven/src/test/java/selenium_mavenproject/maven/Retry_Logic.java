package selenium_mavenproject.maven;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry_Logic implements IRetryAnalyzer{

	int retry=2;
	int count = 0;
	@Override
	public boolean retry(ITestResult result) {
		
		if(count<2)
		{
			count++;
			return false;	
		}
		
		
		return false;
	}

}
